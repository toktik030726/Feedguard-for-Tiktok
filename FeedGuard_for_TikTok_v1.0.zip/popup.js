
document.addEventListener('DOMContentLoaded',()=>{
  const defaults={enabled:true,skipAds:true,skipLive:true,hideFallback:true,instantHide:true,speedMode:'fast',stats:{},dailyStats:{}};
  const today=()=>new Date().toISOString().slice(0,10);
  function render(d){
    const on=d.enabled!==false; state.textContent=on?'enabled':'disabled'; state.className='state '+(on?'enabled':'disabled'); statusBox.className='status '+(on?'enabled':'disabled'); sub.textContent=on?'Filtering is active':'Filtering is paused'; pauseBtn.textContent=on?'Pause':'Resume'; pauseBtn.className=on?'pause':'resume';
    skipAds.checked=d.skipAds!==false; skipLive.checked=d.skipLive!==false; hideFallback.checked=d.hideFallback!==false; instantHide.checked=d.instantHide!==false; speedMode.value=d.speedMode||'fast';
    const st=d.stats||{}, day=(d.dailyStats||{})[today()]||{}; mTotal.textContent=st.total||0; mToday.textContent=day.total||0; mAds.textContent=st.ad||0; mLive.textContent=st.live||0;
  }
  function load(){ chrome.storage.local.get(defaults,render); }
  pauseBtn.onclick=()=>chrome.storage.local.get(defaults,d=>chrome.storage.local.set({enabled:!(d.enabled!==false)},load));
  skipAds.onchange=()=>chrome.storage.local.set({skipAds:skipAds.checked});
  skipLive.onchange=()=>chrome.storage.local.set({skipLive:skipLive.checked});
  hideFallback.onchange=()=>chrome.storage.local.set({hideFallback:hideFallback.checked});
  instantHide.onchange=()=>chrome.storage.local.set({instantHide:instantHide.checked});
  speedMode.onchange=()=>chrome.storage.local.set({speedMode:speedMode.value});
  options.onclick=()=>chrome.runtime.openOptionsPage();
  load(); chrome.storage.onChanged.addListener(load);
});
