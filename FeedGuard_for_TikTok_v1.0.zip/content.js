
(() => {
  'use strict';
  const VERSION = '1.0.0';
  const DEFAULTS = {
    enabled: true,
    skipAds: true,
    skipLive: true,
    skipVerified: false,
    hideFallback: true,
    speedMode: 'fast',
    blocked: [],
    whitelist: [],
    keywords: [],
    hashtags: [],
    stats: {},
    dailyStats: {},
    recentLogs: [],
    instantHide: true
  };
  const SPEED = {
    gentle:     { scan: 900, mo: 250, cooldown: 3000, repeat: 14000, hideDelay: 900 },
    fast:       { scan: 350, mo: 80,  cooldown: 1800, repeat: 7000,  hideDelay: 450 },
    aggressive: { scan: 180, mo: 30,  cooldown: 1000, repeat: 4000,  hideDelay: 220 }
  };
  let lastSkipAt = 0, lastSig = '', initialized = false, intervalId = null, lastAppliedSpeed = '';
  const norm = v => String(v ?? '').toLowerCase();
  const cleanUserList = v => Array.isArray(v) ? v.map(x => norm(x).trim().replace(/^@/, '')).filter(Boolean) : [];
  const cleanWordList = v => Array.isArray(v) ? v.map(x => norm(x).trim()).filter(Boolean) : [];
  const cleanTagList = v => Array.isArray(v) ? v.map(x => norm(x).trim().replace(/^#/, '')).filter(Boolean) : [];
  async function getCfg(){ return Object.assign({}, DEFAULTS, await chrome.storage.local.get(DEFAULTS)); }
  function getSpeed(s){ return SPEED[s.speedMode] || SPEED.fast; }
  function todayKey(){ return new Date().toISOString().slice(0,10); }
  async function addStat(reason, detail){
    const d = await chrome.storage.local.get(['stats','dailyStats','recentLogs']);
    const stats = d.stats || {}, daily = d.dailyStats || {}, logs = d.recentLogs || [];
    const day = todayKey();
    daily[day] = daily[day] || { total:0, ad:0, live:0, hashtag:0, keyword:0, blocked:0, verified:0 };
    stats[reason] = (stats[reason] || 0) + 1; stats.total = (stats.total || 0) + 1;
    daily[day][reason] = (daily[day][reason] || 0) + 1; daily[day].total = (daily[day].total || 0) + 1;
    stats.lastReason = reason; stats.lastDetail = detail || ''; stats.lastAt = new Date().toISOString();
    logs.unshift({ at: new Date().toISOString(), reason, detail: detail || '' });
    await chrome.storage.local.set({ stats, dailyStats: daily, recentLogs: logs.slice(0,100) });
  }
  function log(...m){ console.log('[FeedCleaner v' + VERSION + ']', ...m); }
  function rect(el){ try { return el && el.getBoundingClientRect ? el.getBoundingClientRect() : null; } catch(_) { return null; } }
  function visibleArea(el){
    const r=rect(el); if(!r || r.width<=0 || r.height<=0) return 0;
    const vh=innerHeight||document.documentElement.clientHeight||0, vw=innerWidth||document.documentElement.clientWidth||0;
    return Math.max(0, Math.min(r.bottom,vh)-Math.max(r.top,0))*Math.max(0, Math.min(r.right,vw)-Math.max(r.left,0));
  }
  function isVisible(el){ return visibleArea(el)>20; }
  function unique(nodes){ const out=[], seen=new Set(); nodes.forEach(n=>{ if(n && !seen.has(n)){seen.add(n);out.push(n);} }); return out; }
  function cards(){
    const nodes=[];
    ['article[data-e2e="recommend-list-item-container"]','article','[data-e2e="feed-video"]','[class*="DivItemContainer"]'].forEach(sel=>document.querySelectorAll(sel).forEach(n=>nodes.push(n)));
    return unique(nodes).filter(n=>!n.dataset.fcHidden);
  }
  function currentCard(){
    const midY=innerHeight*0.5, leftZoneX=Math.min(innerWidth*0.25,360); let best=null, score=0;
    for(const c of cards()){
      const r=rect(c); if(!r) continue;
      const s=visibleArea(c)+(r.top<=midY && r.bottom>=midY ? 2000000:0)+(r.left<leftZoneX && r.right>30 ? 500000:0);
      if(s>score){best=c;score=s;}
    }
    return best;
  }
  function cardText(card){ return norm(card?.innerText || ''); }
  function signature(card){ const r=rect(card)||{top:0,height:0}; return cardText(card).slice(0,220)+'|'+Math.round(r.top)+'|'+Math.round(r.height); }
  function visibleIn(card, selector){ return !!card && Array.from(card.querySelectorAll(selector)).some(isVisible); }
  function username(card){ const a=card?.querySelector?.('a[data-e2e="video-author-avatar"], a[href^="/@"]'); return norm((a?.getAttribute?.('href')||'').replace('/@','').split('/')[0]); }
  function extractHashtags(card){
    const tags=new Set(), txt=cardText(card); (txt.match(/#[\p{L}\p{N}_.-]+/gu)||[]).forEach(x=>tags.add(norm(x).replace(/^#/,'')));
    card?.querySelectorAll?.('a[href*="/tag/"]').forEach(a=>{ const href=norm(a.getAttribute('href')||''); const m=href.match(/\/tag\/([^/?#]+)/); if(m&&m[1]){ try{tags.add(decodeURIComponent(m[1]).replace(/^#/,''));}catch(_){tags.add(m[1].replace(/^#/,''));} } const label=norm(a.innerText||a.textContent||'').replace(/^#/,''); if(label) tags.add(label); });
    return [...tags].filter(Boolean);
  }
  function escapeRegex(s){ return String(s).replace(/[.*+?^${}()|[\]\\]/g,'\\$&'); }
  function wildcardToRegex(pattern){ return new RegExp('^'+String(pattern).split('*').map(escapeRegex).join('.*')+'$','i'); }
  function hashtagMatches(filter, tags, visibleText){
    const f=norm(filter).replace(/^#/,'').trim(); if(!f) return false;
    if(f.includes('*')) return tags.some(tag=>wildcardToRegex(f).test(tag));
    if(tags.includes(f)) return true;
    return new RegExp('(^|\\s|\\n)#'+escapeRegex(f)+'(?=$|\\s|\\n|[^\\p{L}\\p{N}_.-])','iu').test(visibleText);
  }
  function isAd(card){ const t=cardText(card); return visibleIn(card,'[data-e2e="ad-tag"]') || visibleIn(card,'[data-e2e="ttam-ads-cta"]') || visibleIn(card,'a[href*="vt.tiktok.com"]') || /(^|\n|\s)(ad|anzeige)(\n|\s|$)/i.test(t) || ['promoted music','jetzt ansehen','read more','learn more','experience now'].some(x=>t.includes(x)); }
  function isLive(card){ const t=cardText(card); return visibleIn(card,'a[href*="/live"]') || visibleIn(card,'[class*="RecommendLivePlayerContainer"]') || ['live anschauen','watch live','jetzt live','klicke, um das live'].some(x=>t.includes(x)) || location.pathname.includes('/live'); }
  function isVerified(card){ return !!(card?.innerHTML?.includes('Verified_Badge') || card?.querySelector?.('g[clip-path*="Verified"], svg *[clip-path*="Verified"]')); }
  function nextCard(card){ const cr=rect(card); if(!cr) return null; let best=null, top=Infinity; for(const c of cards()){ if(c===card) continue; const r=rect(c); if(r && r.top>cr.top+50 && r.top<top){best=c;top=r.top;} } return best; }
  function keyAndWheel(){ const amount=Math.max(innerHeight,850); const key={key:'ArrowDown',code:'ArrowDown',keyCode:40,which:40,bubbles:true,cancelable:true,composed:true}; try{window.dispatchEvent(new KeyboardEvent('keydown',key));document.dispatchEvent(new KeyboardEvent('keydown',key));window.dispatchEvent(new KeyboardEvent('keyup',key));document.dispatchEvent(new KeyboardEvent('keyup',key));window.dispatchEvent(new WheelEvent('wheel',{deltaY:amount,deltaMode:0,bubbles:true,cancelable:true,composed:true}));}catch(_){} }
  function scrollContainers(card){ const amount=Math.max(innerHeight,850); let el=card; while(el && el!==document.body && el!==document.documentElement){ try{ if(el.scrollHeight>el.clientHeight+30) el.scrollTop+=amount; }catch(_){} el=el.parentElement; } try{document.scrollingElement.scrollTop+=amount;}catch(_){} try{window.scrollBy({top:amount,behavior:'auto'});}catch(_){} }
  function hideCard(card){ if(!card || card.dataset.fcHidden) return; card.dataset.fcHidden='1'; ['display:none','height:0px','min-height:0px','max-height:0px','overflow:hidden','opacity:0','pointer-events:none'].forEach(rule=>{ const [k,v]=rule.split(':'); card.style.setProperty(k,v,'important'); }); }
  function move(card, settings){ const sp=getSpeed(settings), next=nextCard(card); if(next){ try{next.scrollIntoView({block:'center',inline:'nearest',behavior:'smooth'});}catch(_){} setTimeout(()=>{try{next.scrollIntoView({block:'center',inline:'nearest',behavior:'auto'});}catch(_){}},Math.max(120,Math.round(sp.hideDelay/2))); } keyAndWheel(); setTimeout(()=>scrollContainers(card),Math.max(60,Math.round(sp.hideDelay/4))); setTimeout(keyAndWheel,Math.max(100,Math.round(sp.hideDelay*0.9))); if(settings.hideFallback!==false) setTimeout(()=>{ if(visibleArea(card)>5000){ log('hide fallback'); hideCard(card); scrollContainers(card); const n=nextCard(card); if(n) try{n.scrollIntoView({block:'center',inline:'nearest',behavior:'auto'});}catch(_){} } },sp.hideDelay); }
  async function skip(reason, card, settings, detail){
    const now=Date.now(), sp=getSpeed(settings), s=signature(card);
    if(now-lastSkipAt<sp.cooldown) return;
    if(s===lastSig && now-lastSkipAt<sp.repeat) return;
    lastSkipAt=now; lastSig=s;
    log('skip',reason,detail||'', 'speed='+settings.speedMode);
    await addStat(reason, detail);
    // Instant-hide reduces visible exposure after a match. It cannot prevent TikTok from loading the item,
    // but it prevents keeping the matched card visible while the skip movement happens.
    if(settings.instantHide !== false) hideCard(card);
    move(card,settings);
  }
  async function scan(){
    try{
      const s=await getCfg(); applySpeedIfNeeded(s); if(!s.enabled) return;
      const card=currentCard(); if(!card) return; const t=cardText(card), u=username(card);
      if(u && cleanUserList(s.whitelist).includes(u)) return;
      if(u && cleanUserList(s.blocked).includes(u)) return skip('blocked',card,s,u);
      if(s.skipAds && isAd(card)) return skip('ad',card,s,'ad-marker');
      if(s.skipLive && isLive(card)) return skip('live',card,s,'live-marker');
      if(s.skipVerified && isVerified(card)) return skip('verified',card,s,u || 'verified');
      for(const k of cleanWordList(s.keywords)) if(k && t.includes(k)) return skip('keyword',card,s,k);
      const tags=extractHashtags(card); for(const h of cleanTagList(s.hashtags)) if(h && hashtagMatches(h,tags,t)) return skip('hashtag',card,s,h);
    }catch(e){ console.error('[FeedCleaner v'+VERSION+']', e); }
  }
  function applySpeedIfNeeded(settings){ const mode=SPEED[settings.speedMode]?settings.speedMode:'fast'; if(mode===lastAppliedSpeed && intervalId) return; lastAppliedSpeed=mode; const sp=SPEED[mode]; if(intervalId) clearInterval(intervalId); intervalId=setInterval(scan,sp.scan); log('speed mode',mode,sp); }
  async function observerScan(){ const s=await getCfg(); setTimeout(scan,getSpeed(s).mo); }
  function init(){ if(initialized) return; initialized=true; log('loaded - english ui / instant-hide'); getCfg().then(s=>applySpeedIfNeeded(s)); if(document.body) new MutationObserver(observerScan).observe(document.body,{childList:true,subtree:true,characterData:true}); scan(); }
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init,{once:true}); else init();
})();
