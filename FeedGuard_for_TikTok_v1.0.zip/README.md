# FeedGuard for TikTok v1.0

FeedGuard filters and skips unwanted TikTok feed content.

Features:
- Skip ads, LIVE videos, hashtags, keywords and blacklisted accounts
- Whitelist support; whitelist has priority over all other filters
- Pause/Resume button with enabled/disabled state
- Speed modes: Gentle, Fast, Aggressive
- Instant hide after match and hide fallback
- Modern dark-mode dashboard
- Statistics and recent match history
- Import/Export JSON backups

Filter syntax:
- Use one filter per line. Commas and semicolons also work.
- Blacklist/Whitelist: usernames only, @ is optional and removed automatically.
- Hashtags: dog = exact #dog, dog* = prefix, *dog* = contains.
- Keywords: contains/substring filter.

Limitation:
Chrome content scripts run after TikTok has loaded page elements. FeedGuard can detect, hide and skip matches quickly, but cannot reliably prevent TikTok from requesting every video before it appears without broad network blocking that may break TikTok.
